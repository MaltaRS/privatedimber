import { BaseContainer } from "@/components/BaseContainer";
import HeaderContainer from "@/components/HeaderContainer";

export default function ChangePasswordScreen() {
    return (
        <BaseContainer>
            <HeaderContainer title="Alterar senha" />
        </BaseContainer>
    );
}
