import { Fragment } from "react";

import { Text, HStack, VStack } from "@/gluestackComponents";

import { PaymentMethods } from "./PaymentMethodSelection";

import { PaymentMethodsResponse } from "@/connection/wallet/WalletConnection";

export const PaymentMethodsDetails = ({
    selectedPaymentMethods,
    paymentMethodsData,
    formattedBalance,
    totalAmount,
    selectedInstallments,
}: {
    selectedPaymentMethods: PaymentMethods;
    paymentMethodsData: PaymentMethodsResponse | undefined;
    formattedBalance: string;
    totalAmount: string;
    selectedInstallments: number;
}) => {
    const card = paymentMethodsData?.paymentMethods.find(
        (method) => method.id === selectedPaymentMethods.cardId,
    );

    return (
        <Fragment>
            <Text
                fontFamily="$heading"
                color="$black"
                size="xl"
                lineHeight={20}
            >
                Forma de pagamento
            </Text>
            <VStack>
                {selectedPaymentMethods.balance && (
                    <HStack justifyContent="space-between">
                        <Text
                            fontFamily="novaBody"
                            lineHeight={22}
                            fontSize={18}
                        >
                            Saldo da carteira
                        </Text>
                        <Text
                            fontFamily="$jakartHeading"
                            color="#000"
                            fontSize={18}
                        >
                            R${" "}
                            {formattedBalance < totalAmount
                                ? formattedBalance
                                : totalAmount}
                        </Text>
                    </HStack>
                )}
                {selectedPaymentMethods.useCard && (
                    <HStack justifyContent="space-between">
                        <Text color="$gray800" fontSize={17}>
                            Cartão de crédito
                        </Text>
                        <Text
                            fontFamily="$jakartHeading"
                            color="#000"
                            fontSize={18}
                        >
                            R$ {totalAmount}
                        </Text>
                    </HStack>
                )}
                {selectedPaymentMethods.cardId && (
                    <HStack justifyContent="space-between">
                        <Text
                            fontFamily="novaBody"
                            lineHeight={22}
                            color="$gray400"
                            fontSize={16}
                        >
                            {card?.cardBrand} ••••
                            {card?.last4}
                        </Text>
                        <Text
                            fontFamily="novaBody"
                            lineHeight={22}
                            color="$gray400"
                            fontSize={14}
                        >
                            {selectedInstallments}x de R${" "}
                            {(
                                parseFloat(totalAmount.replace(",", ".")) /
                                selectedInstallments
                            )
                                .toFixed(2)
                                .replace(".", ",")}{" "}
                            sem juros
                        </Text>
                    </HStack>
                )}
                {selectedPaymentMethods.pix && (
                    <HStack justifyContent="space-between">
                        <Text color="$gray800" fontSize={17}>
                            Pix
                        </Text>
                        <Text
                            fontFamily="$jakartHeading"
                            color="#000"
                            fontSize={18}
                        >
                            R$ {totalAmount}
                        </Text>
                    </HStack>
                )}
            </VStack>
        </Fragment>
    );
};
