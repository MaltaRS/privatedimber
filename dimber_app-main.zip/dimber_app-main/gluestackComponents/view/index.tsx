export { View } from "react-native";
