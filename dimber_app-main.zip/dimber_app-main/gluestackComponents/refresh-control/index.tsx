import { styled } from "@gluestack-style/react";
import { RefreshControl as RNRefreshControl } from "react-native";
export const RefreshControl = styled(RNRefreshControl, {});
