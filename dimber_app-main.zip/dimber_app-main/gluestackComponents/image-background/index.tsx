import { styled } from "@gluestack-style/react";
import { ImageBackground as RNImageBackground } from "react-native";
export const ImageBackground = styled(RNImageBackground, {});
