import { gluestackUIConfig } from "@/gluestackComponents/gluestack-ui.config";

export const Colors = gluestackUIConfig.tokens.colors;
